import csv
import openpyxl
import glob
import copy
import Curve
from My_interpolation_method import ST_method


class Lake:
    def __init__(self, name):
        self.lake_name = name
        self.lake_data = []
        self.year_count = 0.0
        self.liner_data = []
        self.square_data = []
        self.cubic_data = []
        self.ST_data = []

    def getdata(self, data):
        self.lake_data = data
        self.year_count = int(len(data) / 12)

    def liner_interpolation(self):
        self.liner_data = Curve.liner_inter(self.lake_data)

    def square_interpolation(self):
        self.year_count = int(len(self.lake_data) / 12)
        self.square_data = copy.deepcopy(self.lake_data)
        for i in range(self.year_count):
            self.square_data[i * 12:i * 12 + 12] = copy.deepcopy(Curve.square_curve(self.lake_data[i * 12:i * 12 + 12]))

    def cubic_interpolation(self):
        self.year_count = int(len(self.lake_data) / 12)
        self.cubic_data = copy.deepcopy(self.lake_data)
        for i in range(self.year_count):
            self.cubic_data[i * 12:i * 12 + 12] = copy.deepcopy(Curve.cubic_curve(self.lake_data[i * 12:i * 12 + 12]))

    def ST_interpolation(self):
        self.ST_data = ST_method.ST_interpolation(self.lake_data)


def extra_data_from_single_csv(csv_path):
    tempLake = Lake("")
    with open(csv_path, 'r', encoding="utf-8") as file:
        reader = csv.reader(file)
        for row in reader:
            if row[1] == "Date":
                pass
            else:
                templ = [row[1], row[2]]
                if int(row[1][:4]) > 2000:
                    tempLake.lake_data.append(templ)
                    tempLake.lake_name = row[3]

    return tempLake


def extra_file_names(file_path):
    file_list = glob.glob(file_path)
    return file_list


def write_data_to_excel(llake, result_name):
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    # First generate first column
    sheet.cell(row=1, column=1, value="Time")
    for m in range(len(llake[0].lake_data)):
        sheet.cell(row=2 + m, column=1, value=llake[0].lake_data[m][0])

    for n in range(len(llake)):
        sheet.cell(row=1, column=2 + n, value=llake[n].lake_name)
        for n1 in range(len(llake[n].lake_data)):
            sheet.cell(row=2 + n1, column=2 + n, value=float(llake[n].lake_data[n1][1]))
    workbook.save(result_name + ".xlsx")
    return 0


def extra_data_from_csv_lists(csv_list_path, result_name="first_result"):
    # the input path of csv paths
    files_list = extra_file_names(csv_list_path + "\\*.csv")
    lakes = []
    for i in range(len(files_list)):
        temp_lake = extra_data_from_single_csv(files_list[i])
        lakes.append(temp_lake)
    write_data_to_excel(lakes, result_name + "_1")
    return result_name + "_h.xlsx"


if __name__ == '__main__':
    # the input path of csv paths
    path = r"F:\Code\Small_lakes_interpolation\Lake_interpolation\Water_WUHAN_JRC"
    extra_data_from_csv_lists(path, "Wuhan_water_JRC_30days")
