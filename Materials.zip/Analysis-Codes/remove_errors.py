import numpy as np
import pandas as pd
import copy



def plotbox_remove_errors(data_p):
    valid_values = []
    for i in range(len(data_p)):
        if data_p[i] == 0:
            pass
        else:
            valid_values.append(data_p[i])
    if len(valid_values) == 0:
        return data_p
    Q1 = np.percentile(valid_values, 25)
    Q3 = np.percentile(valid_values, 75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    for m in range(len(data_p)):
        if upper_bound > data_p[m] > lower_bound:
            pass
        else:
            data_p[m] = 0

    return data_p


def remove_err(r_data, step=2):
    max_value = max(r_data)
    # remove errors firstly by remove the data which is too small,
    # for example: the area smaller than 20% of the area lake
    for i1 in range(len(r_data)):
        if r_data[i1] < 0.15 * max_value:
            r_data[i1] = 0
        else:
            pass
    if step == 1:
        return r_data
    # remove errors by the mean of plotbox method
    r_data = plotbox_remove_errors(r_data)
    return r_data


def remove_errors_all(path, sheet_name="Sheet1", out_name="Second_result"):
    df = pd.read_excel(path, sheet_name)
    row = df.values.shape[0]
    column = df.values.shape[1]
    data = df.values[:, 1:column]
    new_data = copy.deepcopy(data)
    for i in range(data.shape[1]):
        new_data[:, i] = remove_err(data[:, i], 2)
        df.iloc[:, i + 1] = new_data[:, i].astype(float)
    df.to_excel(out_name, index=False)
    return out_name


if __name__ == "__main__":
    excel_file_path = r'Wuhan_water_30days_2.xlsx'

    remove_errors_all(excel_file_path, "Sheet1", "Wuhan_water_30days_3.xlsx")
