import openpyxl
import pandas as pd


def extract_top_correlations(excel_file_path, sheet_name="Sheet1", top_n=3, result_name="top_correlations"):
    # 读取 Excel 文件
    df = pd.read_excel(excel_file_path, sheet_name=sheet_name, index_col=0)

    # 创建一个新的工作簿用于保存结果
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.cell(row=1, column=1, value="Lake Name")
    sheet.cell(row=1, column=2, value="Top 3 Related Lakes")
    sheet.cell(row=1, column=3, value="Top 3 Correlation Values")

    # 获取湖泊名字（列名）
    lakes = df.columns.tolist()

    # 遍历每个湖泊，找到与其最相关的前三个湖泊
    row = 2
    for lake in lakes:
        # 获取当前湖泊的相关性行
        correlations = df[lake].drop(lake)  # 排除自身
        # 排序并选择前三个相关湖泊
        top_correlations = correlations.sort_values(ascending=False).head(top_n)

        # 写入结果到 Excel
        sheet.cell(row=row, column=1, value=lake)
        sheet.cell(row=row, column=2, value=", ".join(top_correlations.index.tolist()))  # 最相关的湖泊
        sheet.cell(row=row, column=3, value=", ".join([str(val) for val in top_correlations.values.tolist()]))  # 相关系数
        row += 1

    # 保存结果到新的 Excel 文件
    workbook.save(result_name + ".xlsx")
    print(f"Top correlations saved as {result_name}.xlsx")
    return 0


# 示例调用
extract_top_correlations('Wuhan_water_correlation_new2.xlsx', sheet_name="Sheet", top_n=3, result_name="lake_top_correlations2")
