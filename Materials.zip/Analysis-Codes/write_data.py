import os
import openpyxl
import pandas as pd
from scipy.stats import pearsonr
import Correlation
from read_data import Lake, extra_data_from_single_csv
import copy
from tqdm import *


def output_correlation_sheet(lakes):
    pass


def read_lake_data(excel_file_path, sheet_name="Sheet2"):
    # 读取 Excel 文件
    lakes = []
    df = pd.read_excel(excel_file_path, sheet_name=sheet_name)

    for i in range(len(df.columns) - 1):
        temp_lake = (Lake(df.columns[i + 1]))
        temp_lake.getdata(df.iloc[:, i + 1])
        # print(temp_lake.lake_name)
        # print(temp_lake.lake_data)
        lakes.append(temp_lake)
    # Pair1 = Correlation.lake_pair(first_column, second_column).remove_empty_values().correlation_coefficient()
    return lakes


def cal_correlation(lakes, result_name):

    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.cell(row=1, column=1, value="")
    for m in range(len(lakes)):
        sheet.cell(row=2 + m, column=1, value=lakes[m].lake_name)
        sheet.cell(row=1, column=2 + m, value=lakes[m].lake_name)

    for i in tqdm(range(len(lakes))):
        for j in range(len(lakes)):
            tem_lakeA = copy.deepcopy(lakes[i])
            tem_lakeB = copy.deepcopy(lakes[j])
            temp_lake_pair = Correlation.lake_pair(tem_lakeA, tem_lakeB)
            # print(temp_lake_pair.lakeA.lake_name, temp_lake_pair.lakeB.lake_name, len(temp_lake_pair.lakeA.lake_data),
            #       len(temp_lake_pair.lakeB.lake_data))
            temp_lake_pair.remove_empty_values()
            temp_lake_pair.cal_relation()
            sheet.cell(row=2 + i, column=2+j, value=temp_lake_pair.correlation_coefficient)
    #
    # kk = Correlation.lake_pair(lakes[1], lakes[12])
    workbook.save(result_name + ".xlsx")
    return 0


if __name__ == "__main__":
    mm = read_lake_data(r'Wuhan_water_JRC_noerror.xlsx', "Sheet1")
    # for i in range(len(mm)):
    #     print(len(mm[i].lake_data))
    kk = cal_correlation(mm, "Wuhan_water_correlation_new2")
