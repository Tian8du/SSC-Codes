from scipy.stats import pearsonr
import Curve
import pandas as pd


class lake_pair:
    def __init__(self, lake1, lake2):
        self.lakeA = lake1
        self.lakeB = lake2
        self.correlation_coefficient = 0.0
        self.p_value = 0.0
        self.interpolation_data = []

    def remove_empty_values(self):
        new_lakeA = []
        new_lakeB = []
        for i in range(len(self.lakeA.lake_data)):
            if self.lakeA.lake_data[i] == 0 or self.lakeB.lake_data[i] == 0:
                pass
            else:
                new_lakeA.append(self.lakeA.lake_data[i])
                new_lakeB.append(self.lakeB.lake_data[i])
        self.lakeA.lake_data = new_lakeA
        self.lakeB.lake_data = new_lakeB
        return 0

    def cal_relation(self):
        """
        This is the function to cal the P-value and correlation_coefficient between two lakes
        :return:
        """
        if len(self.lakeA.lake_data) > 2:
            self.correlation_coefficient, self.p_value = pearsonr(self.lakeA.lake_data, self.lakeB.lake_data)
        else:
            self.correlation_coefficient, self.p_value = 0.0, 0.0

    def near_interpolation(self):
        """
        This is the function to cal the missing lake area by closed relative lakes
        :return:
        """
        for i in range(len(self.lakeA.lake_data)):
            if i == 0 or i == len(self.lakeA.lake_data) - 1:
                self.interpolation_data.append(self.lakeA.lake_data[i])
            else:
                y1, y2, y3 = self.lakeA.lake_data[i - 1], self.lakeA.lake_data[i], self.lakeA.lake_data[i + 1]
                x1, x2, x3 = self.lakeB.lake_data[i - 1], self.lakeB.lake_data[i], self.lakeB.lake_data[i + 1]
                temp = 0.0
                if y1 != 0 and y3 != 0 and x1 != 0 and x2 != 0 and x3 != 0:
                    temp = (2 * x2 * y3 * y1) / (x3 * y1 + x1 * y3)
                elif (y1 != 0 and x1 != 0 and x2 != 0) and (y3 == 0 or x3 == 0):
                    temp = (x2 * y1) / x1
                elif (x2 != 0 and y3 != 0 and x3 != 0) and (y1 == 0 or x1 == 0):
                    temp = (x2 * y3) / x3
                else:
                    temp = -999
                self.interpolation_data.append(temp)

    def near_interpolation2(self):
        """
        This is the function to cal the missing lake area by closed relative lakes
        :return:
        """
        for i in range(len(self.lakeA.lake_data)):
            if i == 0 or i == len(self.lakeA.lake_data) - 1:
                self.interpolation_data.append(self.lakeA.lake_data[i])
            else:
                y1, y2, y3 = self.lakeA.lake_data[i - 1], self.lakeA.lake_data[i], self.lakeA.lake_data[i + 1]
                x1, x2, x3 = self.lakeB.lake_data[i - 1], self.lakeB.lake_data[i], self.lakeB.lake_data[i + 1]
                temp = 0.0
                if x3 * y1 + x1 * y3 != 0:
                    temp1 = (2 * x2 * y3 * y1) / (x3 * y1 + x1 * y3)
                else:
                    temp1 = -999
                if x1 != 0:
                    temp2 = (x2 * y1) / x1
                else:
                    temp2 = -999
                if x3 != 0:
                    temp3 = (x2 * y3) / x3
                else:
                    temp3 = -999
                if self.lakeA.lake_data[i] != 0:
                    # changed
                    A = Curve.closest_number(temp1, temp2, temp3, self.lakeA.liner_data[i])
                else:
                    A = Curve.closest_number(temp1, temp2, temp3, self.lakeA.liner_data[i])
                if A > 0:
                    self.interpolation_data.append(A)
                else:
                    self.interpolation_data.append(self.lakeA.liner_data[i])



    def forward_near_interpolation(self):
        for i in range(len(self.lakeA.lake_data)):
            if i == 0 or i == len(self.lakeA.lake_data) - 1:
                self.interpolation_data.append(self.lakeA.lake_data[i])
            else:
                y1, y2, y3 = self.lakeA.lake_data[i - 1], self.lakeA.lake_data[i], self.lakeA.lake_data[i + 1]
                x1, x2, x3 = self.lakeB.lake_data[i - 1], self.lakeB.lake_data[i], self.lakeB.lake_data[i + 1]
                if x1 == 0:
                    temp = -999
                else:
                    temp = (x2 * y1) / x1

                self.interpolation_data.append(temp)


if __name__ == "__main__":
    # # 读取 Excel 文件
    # excel_file_path = 'Wuhan_water_30days_2_test.xlsx'  # 替换为你的 Excel 文件路径
    # df = pd.read_excel(excel_file_path)
    #
    # # 获取第一列的数据
    # first_column = df.iloc[:, 1]
    # second_column = df.iloc[:, 2]
    #
    # Pair1 = lake_pair(first_column, second_column).remove_empty_values()
    # correlation_coefficient, p_value = pearsonr(Pair1.lakeA, Pair1.lakeB)
    # print(f"Pearson correlation coefficient: {correlation_coefficient}")
    # print(f"P-value: {p_value}")

    # # 打印第一列的数据
    # print(first_column)
    # print(Pair1.lakeA)
    # print(Pair1.lakeB)
    # print("num of lens", len(df))
    pass
