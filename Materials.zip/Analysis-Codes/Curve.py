import copy

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.interpolate import CubicSpline

from scipy.interpolate import lagrange


def cubic_spline_interpolation(x_data, y_data, new_x):
    """
    使用三次样条插值进行插值

    参数：
    - x_data: 已知数据点的 x 值列表
    - y_data: 已知数据点的 y 值列表
    - new_x: 要进行插值的新 x 值

    返回：
    - 插值结果 y
    """
    # 创建三次样条插值对象
    cubic_spline = CubicSpline(x_data, y_data)

    # 计算对应的插值结果
    new_y = cubic_spline(new_x)

    return new_y


def cubic_spline_inter(list1):
    list = []
    x_data = []
    for i in range(len(list1)):
        if list1[i] == 0:
            pass
        else:
            list.append(list1[i])
            x_data.append(i)
    y_data = list

    list2 = []
    for i in range(len(list1)):
        if i in x_data:
            index_of_i = x_data.index(i)
            tempx_data = copy.deepcopy(x_data)
            tempy_data = copy.deepcopy(y_data)
            tempx_data = np.delete(tempx_data, index_of_i)
            tempy_data = np.delete(tempy_data, index_of_i)
            temp = cubic_spline_interpolation(tempx_data, tempy_data, i)
            list2.append(temp)
        else:
            temp = cubic_spline_interpolation(x_data, y_data, i)
            list2.append(temp)

    return list2


def div_diff(x, y):
    """
    计算差商数组

    参数：
    - x: 已知数据点的 x 值列表
    - y: 已知数据点的 y 值列表

    返回：
    - 差商数组
    """
    n = len(x)
    F = np.zeros((n, n))
    F[:, 0] = y
    for j in range(1, n):
        for i in range(n - j):
            F[i, j] = (F[i + 1, j - 1] - F[i, j - 1]) / (x[i + j] - x[i])
    return F[0, :]


def newton_interpolation(x_data, y_data, new_x):
    """
    使用牛顿插值进行插值

    参数：
    - x_data: 已知数据点的 x 值列表
    - y_data: 已知数据点的 y 值列表
    - new_x: 要进行插值的新 x 值

    返回：
    - 插值结果 y
    """
    coefficients = div_diff(x_data, y_data)

    result = coefficients[0]
    for i in range(1, len(coefficients)):
        term = coefficients[i]
        for j in range(i):
            term *= (new_x - x_data[j])
        result += term

    return result


def newton_inter(list1):
    list = []
    x_data = []
    for i in range(len(list1)):
        if list1[i] == 0:
            pass
        else:
            list.append(list1[i])
            x_data.append(i)
    y_data = list

    list2 = []
    for i in range(len(list1)):
        temp = newton_interpolation(x_data, y_data, i)
        list2.append(temp)
    return list2


def lagrange_interpolation(x_data, y_data, x):
    """
    使用拉格朗日插值进行插值

    参数：
    - x_data: 已知数据点的 x 值列表
    - y_data: 已知数据点的 y 值列表
    - x: 要进行插值的新 x 值

    返回：
    - 插值结果 y
    """
    n = len(x_data)
    result = 0.0

    for i in range(n):
        term = y_data[i]
        for j in range(n):
            if i != j:
                term *= (x - x_data[j]) / (x_data[i] - x_data[j])
        result += term

    return result


def lagrange_inter(list1):
    list = []
    x_data = []
    for i in range(len(list1)):
        if list1[i] == 0:
            pass
        else:
            list.append(list1[i])
            x_data.append(i)
    y_data = list

    list2 = []
    for i in range(len(list1)):
        temp = lagrange_interpolation(x_data, y_data, i)
        list2.append(temp)
    return list2


def closest_number(a, b, c, d):
    # 计算每个数与d的差值的绝对值
    diff_a = abs(a - d)
    diff_b = abs(b - d)
    diff_c = abs(c - d)

    # 找到最小的差值对应的数
    closest = min((a, diff_a), (b, diff_b), (c, diff_c), key=lambda x: x[1])

    return closest[0]


def quadratic_fit(x, a, b, c):
    return a * x ** 2 + b * x + c


# 定义三次多项式拟合函数
def cubic_fit(x, a, b, c, d):
    return a * x ** 3 + b * x ** 2 + c * x + d


def square_curve(areas):
    # months = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])
    # lake_area = np.array([100, 120, 150, 180, 200, 220, 250, 280, 300, 320, 350, 380])
    months = []
    lake_area = []
    for i in range(12):
        if areas[i] == 0:
            pass
        else:
            lake_area.append(areas[i])
            months.append(i + 1)

    # 利用curve_fit进行拟合
    params, covariance = curve_fit(quadratic_fit, months, lake_area)

    # 获取拟合系数
    a, b, c = params

    # 生成拟合曲线的x值
    fit_months = np.linspace(1, 12, 12)

    # 计算拟合曲线的y值
    fit_lake_area = quadratic_fit(fit_months, a, b, c)
    # print("months", months)
    # print("lakes", lake_area)
    return fit_lake_area


def cubic_curve(areas):
    months = []
    lake_area = []
    for i in range(12):
        if areas[i] == 0:
            pass
        else:
            lake_area.append(areas[i])
            months.append(i + 1)

    # 利用curve_fit进行拟合
    params, covariance = curve_fit(cubic_fit, months, lake_area)

    # 获取拟合系数
    a, b, c, d = params

    # 生成拟合曲线的x值
    fit_months = np.linspace(1, 12, 12)

    # 计算拟合曲线的y值
    fit_lake_area = cubic_fit(fit_months, a, b, c, d)
    return fit_lake_area


def liner_inter(areas):
    months = []
    lake_area = []
    for i in range(len(areas)):
        lake_area.append(areas[i])
        months.append(i)

    nonzero_indices = np.nonzero(lake_area)
    months = np.array(months)
    lake_area = np.array(lake_area)

    # 执行线性插值
    interpolated_lake_area = np.interp(months, months[nonzero_indices], lake_area[nonzero_indices])

    return interpolated_lake_area


def liner_inter2(areas):
    """
    This is the function to interpolation data not using true datas
    :param areas:
    :return:
    """
    out_areas = []

    for i in range(len(areas)):

        if i == 0 or i == len(areas) - 1:
            out_areas.append(areas[i])
        else:

            out = (areas[i - 1] + areas[i + 1]) / 2
            out_areas.append(out)
    return out_areas


def calculate_metrics(list1, list2):
    """
    Calculate RMS, MAE, and correlation between two lists.

    Parameters:
    - list1: First list of data
    - list2: Second list of data

    Returns:
    - rms: Root Mean Square
    - mae: Mean Absolute Error
    - correlation: Pearson correlation coefficient
    """
    # remove 0 data
    listA = []
    listB = []
    for i in range(len(list1)):
        if list1[i] != 0:
            listA.append(list1[i])
            listB.append(list2[i])
    list1 = listA
    list2 = listB
    # Convert lists to NumPy arrays
    array1 = np.array(list1)
    array2 = np.array(list2)

    # Calculate RMS
    rms = np.sqrt(np.mean((array1 - array2) ** 2))

    # Calculate MAE
    mae = np.mean(np.abs(array1 - array2))

    # Calculate correlation coefficient
    correlation = np.corrcoef(array1, array2)[0, 1]

    return rms, mae, correlation


def swap_lake_areas(values, group_size=12):
    """
    将湖泊面积按每 group_size（默认12）分组，排序后交换每组中最大和最小的位置。

    参数：
        values (list): 包含湖泊面积的列表，每 group_size 个为一个湖泊。
        group_size (int): 每组的大小（默认为 12）。

    返回：
        list: 调换最大和最小位置后的列表。
    """
    # 确保 values 长度是 group_size 的倍数
    if len(values) % group_size != 0:
        raise ValueError("列表长度必须是每组大小的整数倍！")

    # 按组分割数据
    n_groups = len(values) // group_size
    lake_data = np.array(values).reshape(n_groups, group_size)

    # 遍历每组并进行最大最小位置交换
    for i, lake in enumerate(lake_data):
        # 排序并获取最小值和最大值的索引
        sorted_indices = np.argsort(lake)  # 从小到大排序，返回索引
        smallest_indices = sorted_indices[:group_size // 2]  # 最小的一半索引
        largest_indices = sorted_indices[-(group_size // 2):]  # 最大的一半索引

        # 交换最小值和最大值的位置
        lake[smallest_indices], lake[largest_indices] = lake[largest_indices], lake[smallest_indices]

    # 将修改后的数据恢复为原始结构
    return lake_data.flatten().tolist()

def SSC_average(list1, list2, de=True):
    out_list = []
    for i in range(len(list1)):
        out_list.append((list1[i] + list2[i]) / 2)
    if out_list[-1] == 0:
        out_list[-1] = (out_list[-2] + out_list[-3]) / 2
    # if de:
        # out_list = de_data(out_list)
        # out_list = de_data(out_list)
        # out_list = de_data(out_list)
        # out_list= swap_lake_areas(out_list)
    return out_list


def SSC_after_process(list1, list2, real, liner, de=True):
    ### change
    out_list = []
    for i in range(len(list1)):
        if real[i] != 0:
            out_list.append(closest_number(list1[i], list2[i], 0, liner[i]))
        else:
            out_list.append(closest_number(list1[i], list2[i], 0, liner[i]))
        if out_list[i] > 40 or out_list ==0:
            out_list[i] = (out_list[i-1] + out_list[i-2])/2
    if out_list[ -1 ] == 0:
        out_list[-1] = (out_list[-2] + out_list[-3])/2
    for i in range(len(out_list)):
        if out_list[i] < 1:
            out_list[i] = (out_list[i-1] + out_list[i-2])/2
    # if de:
        # out_list = de_data(out_list)
        # out_list = de_data(out_list)
        # out_list = de_data(out_list)
        # out_list= swap_lake_areas(out_list)

    return out_list

def de_data(values):
    # 1. 计算均值
    mean_value = np.mean(values)

    # 2. 计算偏差值
    deviations = np.array(values) - mean_value

    # 3. 压缩偏差值（使用平方根进行压缩，可以改为其他函数）
    compressed_deviations = np.sign(deviations) * np.sqrt(np.abs(deviations))

    # 4. 恢复压缩后的数据
    compressed_values = mean_value + compressed_deviations
    return compressed_values

area_list = [100, 120, 150, 180, 200, 220, 250, 280, 300, 320, 350, 380, 200, 100, 0, 0, 0, 200, 340]
area_list2 = [
    2.428045037,
    2.114308894,
    2.169121926,
    2.229106636,
    2.344410901,
    0,
    1.899824656,
    1.967650284,
    1.890273544,
    2.089315624,
    2.135123575,
    2.109892682
]

# 绘制原始数据和拟合曲线
# plt.scatter(months, lake_area, label='Actual Data')
# plt.plot(fit_months, fit_lake_area, 'r-', label='Quadratic Fit')
# plt.xlabel('Month')
# plt.ylabel('Lake Area')
# plt.title('Lake Area Fitting for 12 Months')
# plt.legend()
# plt.show()
